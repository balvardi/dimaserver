<?php
require_once 'config/database.php';

class Order {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function create($user_id, $package_id, $domain, $period, $amount) {
        $order_number = 'DMS' . date('Ymd') . rand(1000, 9999);
        
        $query = "INSERT INTO orders (order_number, user_id, package_id, domain, period, amount, status, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())";
        
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$order_number, $user_id, $package_id, $domain, $period, $amount])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }
    
    public function getById($id) {
        $query = "SELECT o.*, p.name as package_name, u.username, u.email 
                  FROM orders o 
                  JOIN packages p ON o.package_id = p.id 
                  JOIN users u ON o.user_id = u.id 
                  WHERE o.id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getByUser($user_id) {
        $query = "SELECT o.*, p.name as package_name 
                  FROM orders o 
                  JOIN packages p ON o.package_id = p.id 
                  WHERE o.user_id = ? 
                  ORDER BY o.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateStatus($id, $status, $transaction_id = null) {
        $query = "UPDATE orders SET status = ?, transaction_id = ?, updated_at = NOW() WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$status, $transaction_id, $id]);
    }
    
    public function getAll($status = null) {
        $query = "SELECT o.*, p.name as package_name, u.username, u.email 
                  FROM orders o 
                  JOIN packages p ON o.package_id = p.id 
                  JOIN users u ON o.user_id = u.id";
        
        if ($status) {
            $query .= " WHERE o.status = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$status]);
        } else {
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
        }
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
