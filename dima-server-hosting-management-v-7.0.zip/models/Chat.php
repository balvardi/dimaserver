<?php
require_once 'config/database.php';

class Chat {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function createSession($user_id, $name, $email) {
        $session_id = uniqid('chat_', true);
        
        $query = "INSERT INTO chat_sessions (session_id, user_id, name, email, status, created_at) 
                  VALUES (?, ?, ?, ?, 'active', NOW())";
        $stmt = $this->conn->prepare($query);
        
        if ($stmt->execute([$session_id, $user_id, $name, $email])) {
            return $session_id;
        }
        return false;
    }
    
    public function getSession($session_id) {
        $query = "SELECT * FROM chat_sessions WHERE session_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$session_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function sendMessage($session_id, $sender_type, $sender_id, $message) {
        $query = "INSERT INTO chat_messages (session_id, sender_type, sender_id, message, created_at) 
                  VALUES (?, ?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$session_id, $sender_type, $sender_id, $message]);
    }
    
    public function getMessages($session_id, $limit = 50) {
        $query = "SELECT cm.*, cs.name as session_name, u.full_name as admin_name 
                  FROM chat_messages cm 
                  LEFT JOIN chat_sessions cs ON cm.session_id = cs.session_id 
                  LEFT JOIN users u ON cm.sender_id = u.id AND cm.sender_type = 'admin'
                  WHERE cm.session_id = ? 
                  ORDER BY cm.created_at ASC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$session_id, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getActiveSessions() {
        $query = "SELECT cs.*, COUNT(cm.id) as message_count,
                         MAX(cm.created_at) as last_message_time
                  FROM chat_sessions cs 
                  LEFT JOIN chat_messages cm ON cs.session_id = cm.session_id 
                  WHERE cs.status = 'active' 
                  GROUP BY cs.id 
                  ORDER BY last_message_time DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function closeSession($session_id) {
        $query = "UPDATE chat_sessions SET status = 'closed', closed_at = NOW() WHERE session_id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$session_id]);
    }
    
    public function getUnreadCount($session_id, $sender_type) {
        $query = "SELECT COUNT(*) as count FROM chat_messages 
                  WHERE session_id = ? AND sender_type != ? AND is_read = 0";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$session_id, $sender_type]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }
    
    public function markAsRead($session_id, $sender_type) {
        $query = "UPDATE chat_messages SET is_read = 1 
                  WHERE session_id = ? AND sender_type != ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$session_id, $sender_type]);
    }
}
?>
