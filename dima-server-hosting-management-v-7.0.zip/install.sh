#!/bin/bash

echo "🚀 نصب DimaServer Hosting Management System"
echo "============================================="

# بررسی وجود PHP
if ! command -v php &> /dev/null; then
    echo "❌ PHP نصب نیست. لطفاً ابتدا PHP را نصب کنید."
    exit 1
fi

echo "✅ PHP نصب شده است"

# بررسی وجود Composer
if ! command -v composer &> /dev/null; then
    echo "⚠️  Composer نصب نیست. در حال نصب..."
    
    # دانلود و نصب Composer
    php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
    php composer-setup.php
    php -r "unlink('composer-setup.php');"
    
    # اضافه کردن Composer به PATH
    sudo mv composer.phar /usr/local/bin/composer
    
    echo "✅ Composer نصب شد"
else
    echo "✅ Composer نصب شده است"
fi

# نصب dependencies
echo "📦 در حال نصب dependencies..."
composer install --no-dev --optimize-autoloader

# کپی فایل‌های تنظیمات
if [ ! -f "config/config.php" ]; then
    cp config/config.example.php config/config.php
    echo "✅ فایل config.php ایجاد شد"
fi

if [ ! -f "config/database.php" ]; then
    cp config/database.example.php config/database.php
    echo "✅ فایل database.php ایجاد شد"
fi

# تنظیم مجوزها
chmod 755 -R .
chmod 777 -R uploads/ 2>/dev/null || mkdir -p uploads && chmod 777 uploads/

echo ""
echo "🎉 نصب با موفقیت تکمیل شد!"
echo ""
echo "📋 مراحل بعدی:"
echo "1. اطلاعات دیتابیس را در config/database.php وارد کنید"
echo "2. تنظیمات DirectAdmin را در config/config.php انجام دهید"
echo "3. اطلاعات زرین‌پال را در config/config.php اضافه کنید"
echo "4. دیتابیس را با اجرای scripts/database_setup.sql ایجاد کنید"
echo "5. وب سرور خود را راه‌اندازی کنید"
echo ""
echo "🔗 آدرس پنل ادمین: http://yoursite.com/admin/"
echo "👤 نام کاربری: admin"
echo "🔑 رمز عبور: admin123"
echo ""
echo "⚠️  هشدار: حتماً رمز عبور پیش‌فرض را تغییر دهید!"
