<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/config.php';
require_once '../models/Chat.php';
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$chat = new Chat();
$auth = new Auth();

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'start':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            
            $user_id = $auth->isLoggedIn() ? $_SESSION['user_id'] : null;
            $name = $data['name'] ?? '';
            $email = $data['email'] ?? '';
            
            if (empty($name) || empty($email)) {
                echo json_encode(['success' => false, 'message' => 'نام و ایمیل الزامی است']);
                exit;
            }
            
            $session_id = $chat->createSession($user_id, $name, $email);
            
            if ($session_id) {
                echo json_encode(['success' => true, 'session_id' => $session_id]);
            } else {
                echo json_encode(['success' => false, 'message' => 'خطا در ایجاد جلسه چت']);
            }
        }
        break;
        
    case 'send':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            
            $session_id = $data['session_id'] ?? '';
            $message = trim($data['message'] ?? '');
            $sender_type = $data['sender_type'] ?? 'user';
            
            if (empty($session_id) || empty($message)) {
                echo json_encode(['success' => false, 'message' => 'اطلاعات ناکامل']);
                exit;
            }
            
            // بررسی وجود جلسه
            $session = $chat->getSession($session_id);
            if (!$session) {
                echo json_encode(['success' => false, 'message' => 'جلسه چت یافت نشد']);
                exit;
            }
            
            $sender_id = null;
            if ($sender_type === 'admin' && $auth->isAdmin()) {
                $sender_id = $_SESSION['user_id'];
            } elseif ($sender_type === 'user') {
                $sender_id = $session['user_id'];
            }
            
            $result = $chat->sendMessage($session_id, $sender_type, $sender_id, $message);
            
            if ($result) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'خطا در ارسال پیام']);
            }
        }
        break;
        
    case 'messages':
        $session_id = $_GET['session_id'] ?? '';
        $last_id = (int)($_GET['last_id'] ?? 0);
        
        if (empty($session_id)) {
            echo json_encode(['success' => false, 'message' => 'شناسه جلسه الزامی است']);
            exit;
        }
        
        $messages = $chat->getMessages($session_id);
        
        // فیلتر پیام‌های جدید
        if ($last_id > 0) {
            $messages = array_filter($messages, function($msg) use ($last_id) {
                return $msg['id'] > $last_id;
            });
        }
        
        echo json_encode(['success' => true, 'messages' => array_values($messages)]);
        break;
        
    case 'sessions':
        if (!$auth->isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
            exit;
        }
        
        $sessions = $chat->getActiveSessions();
        echo json_encode(['success' => true, 'sessions' => $sessions]);
        break;
        
    case 'close':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $session_id = $data['session_id'] ?? '';
            
            if (empty($session_id)) {
                echo json_encode(['success' => false, 'message' => 'شناسه جلسه الزامی است']);
                exit;
            }
            
            $result = $chat->closeSession($session_id);
            echo json_encode(['success' => $result]);
        }
        break;
        
    case 'mark_read':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = json_decode(file_get_contents('php://input'), true);
            $session_id = $data['session_id'] ?? '';
            $sender_type = $data['sender_type'] ?? 'user';
            
            $result = $chat->markAsRead($session_id, $sender_type);
            echo json_encode(['success' => $result]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'عملیات نامعتبر']);
        break;
}
?>
