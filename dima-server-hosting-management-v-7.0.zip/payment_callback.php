<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
require_once 'models/Order.php';
require_once 'includes/zarinpal.php';
require_once 'includes/directadmin.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$orderModel = new Order();
$zarinpal = new ZarinPal();

$order_id = $_GET['order_id'] ?? null;
$authority = $_GET['Authority'] ?? null;
$status = $_GET['Status'] ?? null;

if (!$order_id || !$authority) {
    header('Location: index.php');
    exit;
}

$order = $orderModel->getById($order_id);
if (!$order || $order['user_id'] != $_SESSION['user_id']) {
    header('Location: index.php');
    exit;
}

$message = '';
$success = false;

if ($status === 'OK') {
    // تایید پرداخت
    $verification = $zarinpal->verify($authority, $order['amount']);
    
    if ($verification['success']) {
        // پرداخت موفق
        $orderModel->updateStatus($order_id, 'paid', $verification['ref_id']);
        
        // ایجاد اکانت هاستینگ در DirectAdmin
        $da = new DirectAdmin();
        $hosting_username = 'user' . $order['user_id'] . '_' . time();
        $hosting_password = bin2hex(random_bytes(8));
        
        $account_result = $da->createAccount(
            $hosting_username,
            $order['email'],
            $hosting_password,
            $order['domain'],
            $order['package_name']
        );
        
        if ($account_result['success']) {
            // ذخیره اطلاعات اکانت
            $database = new Database();
            $conn = $database->getConnection();
            
            $query = "INSERT INTO hosting_accounts (user_id, order_id, username, domain, package_id, expires_at) 
                      VALUES (?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MONTH))";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                $order['user_id'], 
                $order_id, 
                $hosting_username, 
                $order['domain'], 
                $order['package_id'], 
                $order['period']
            ]);
            
            $orderModel->updateStatus($order_id, 'completed');
            
            $success = true;
            $message = "پرداخت با موفقیت انجام شد. اکانت هاستینگ شما ایجاد گردید.";
            
            // ارسال ایمیل اطلاعات اکانت به کاربر
            // کد ارسال ایمیل...
            
        } else {
            $message = "پرداخت موفق بود اما خطا در ایجاد اکانت هاستینگ. با پشتیبانی تماس بگیرید.";
        }
    } else {
        $orderModel->updateStatus($order_id, 'failed');
        $message = "خطا در تایید پرداخت";
    }
} else {
    $orderModel->updateStatus($order_id, 'cancelled');
    $message = "پرداخت لغو شد";
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتیجه پرداخت - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Tahoma', sans-serif; background: #f8f9fa; }
        .result-card { max-width: 600px; margin: 100px auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card result-card">
            <div class="card-body text-center">
                <?php if ($success): ?>
                    <i class="fas fa-check-circle fa-5x text-success mb-4"></i>
                    <h3 class="text-success">پرداخت موفق</h3>
                    <p class="lead"><?php echo $message; ?></p>
                    <div class="alert alert-info">
                        <strong>شماره سفارش:</strong> <?php echo $order['order_number']; ?><br>
                        <strong>مبلغ:</strong> <?php echo number_format($order['amount']); ?> تومان<br>
                        <strong>کد پیگیری:</strong> <?php echo $verification['ref_id'] ?? 'نامشخص'; ?>
                    </div>
                    <a href="dashboard.php" class="btn btn-primary">مشاهده پنل کاربری</a>
                <?php else: ?>
                    <i class="fas fa-times-circle fa-5x text-danger mb-4"></i>
                    <h3 class="text-danger">پرداخت ناموفق</h3>
                    <p class="lead"><?php echo $message; ?></p>
                    <a href="index.php" class="btn btn-primary">بازگشت به صفحه اصلی</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
