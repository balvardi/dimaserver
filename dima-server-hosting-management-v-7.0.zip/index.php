<?php
require_once 'config/config.php';
require_once 'models/Package.php';

$packageModel = new Package();
$packages = $packageModel->getAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - هاستینگ حرفه‌ای ایران</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary-color: #64748b;
            --accent-color: #f59e0b;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --warning-color: #f59e0b;
            --dark-color: #0f172a;
            --light-color: #f8fafc;
            --border-color: #e2e8f0;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-secondary: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: var(--text-primary);
            background-color: #ffffff;
        }

        /* Navigation */
        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 0;
            transition: all 0.3s ease;
        }

        .navbar-custom.scrolled {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: var(--shadow-md);
        }

        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            color: var(--primary-color) !important;
            text-decoration: none;
        }

        .navbar-nav .nav-link {
            font-weight: 500;
            color: var(--text-primary) !important;
            margin: 0 0.5rem;
            padding: 0.5rem 1rem !important;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            background-color: var(--light-color);
            color: var(--primary-color) !important;
        }

        .btn-login {
            background: var(--primary-color);
            color: white !important;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        /* Hero Section */
        .hero-section {
            background: var(--gradient-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><defs><radialGradient id="a" cx="50%" cy="50%"><stop offset="0%" stop-color="%23ffffff" stop-opacity="0.1"/><stop offset="100%" stop-color="%23ffffff" stop-opacity="0"/></radialGradient></defs><circle cx="200" cy="200" r="100" fill="url(%23a)"/><circle cx="800" cy="300" r="150" fill="url(%23a)"/><circle cx="400" cy="700" r="120" fill="url(%23a)"/></svg>');
            opacity: 0.3;
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 800;
            color: white;
            margin-bottom: 1.5rem;
            line-height: 1.2;
        }

        .hero-subtitle {
            font-size: 1.25rem;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 2rem;
            font-weight: 400;
        }

        .hero-stats {
            display: flex;
            gap: 2rem;
            margin-top: 3rem;
        }

        .hero-stat {
            text-align: center;
            color: white;
        }

        .hero-stat-number {
            font-size: 2rem;
            font-weight: 700;
            display: block;
        }

        .hero-stat-label {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .btn-hero {
            background: white;
            color: var(--primary-color);
            border: none;
            padding: 1rem 2rem;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-lg);
        }

        .btn-hero:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-xl);
            color: var(--primary-color);
        }

        /* Packages Section */
        .packages-section {
            padding: 6rem 0;
            background: var(--light-color);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 1rem;
            color: var(--text-primary);
        }

        .section-subtitle {
            font-size: 1.1rem;
            color: var(--text-secondary);
            text-align: center;
            margin-bottom: 4rem;
        }

        .package-card {
            background: white;
            border-radius: 1rem;
            padding: 2rem;
            height: 100%;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .package-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
        }

        .package-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
            border-color: var(--primary-color);
        }

        .package-card.featured {
            border-color: var(--primary-color);
            box-shadow: var(--shadow-lg);
            transform: scale(1.05);
        }

        .package-card.featured::before {
            background: var(--gradient-secondary);
        }

        .package-badge {
            position: absolute;
            top: -1px;
            right: 2rem;
            background: var(--gradient-secondary);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 0 0 0.5rem 0.5rem;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .package-name {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }

        .package-description {
            color: var(--text-secondary);
            margin-bottom: 2rem;
            font-size: 0.95rem;
        }

        .package-price {
            text-align: center;
            margin-bottom: 2rem;
        }

        .price-amount {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary-color);
            line-height: 1;
        }

        .price-currency {
            font-size: 1rem;
            color: var(--text-secondary);
            margin-right: 0.5rem;
        }

        .price-period {
            font-size: 0.9rem;
            color: var(--text-secondary);
            display: block;
            margin-top: 0.25rem;
        }

        .package-features {
            list-style: none;
            margin-bottom: 2rem;
        }

        .package-features li {
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            font-size: 0.95rem;
        }

        .package-features li:last-child {
            border-bottom: none;
        }

        .package-features i {
            color: var(--success-color);
            margin-left: 0.75rem;
            font-size: 1rem;
        }

        .btn-package {
            width: 100%;
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 1rem;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .btn-package:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
            color: white;
        }

        .package-card.featured .btn-package {
            background: var(--gradient-secondary);
            border: none;
        }

        /* Features Section */
        .features-section {
            padding: 6rem 0;
            background: white;
        }

        .feature-card {
            text-align: center;
            padding: 2rem;
            border-radius: 1rem;
            transition: all 0.3s ease;
            height: 100%;
        }

        .feature-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }

        .feature-icon {
            width: 80px;
            height: 80px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            color: white;
            font-size: 2rem;
        }

        .feature-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--text-primary);
        }

        .feature-description {
            color: var(--text-secondary);
            line-height: 1.6;
        }

        /* Stats Section */
        .stats-section {
            padding: 4rem 0;
            background: var(--gradient-primary);
            color: white;
        }

        .stat-item {
            text-align: center;
            padding: 1rem;
        }

        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            display: block;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            font-size: 1rem;
            opacity: 0.9;
        }

        /* Footer */
        .footer {
            background: var(--dark-color);
            color: white;
            padding: 3rem 0 1rem;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .footer-section h5 {
            font-weight: 600;
            margin-bottom: 1rem;
            color: white;
        }

        .footer-section ul {
            list-style: none;
        }

        .footer-section ul li {
            margin-bottom: 0.5rem;
        }

        .footer-section ul li a {
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-section ul li a:hover {
            color: white;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 1rem;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-stats {
                flex-direction: column;
                gap: 1rem;
            }
            
            .package-card.featured {
                transform: none;
            }
            
            .section-title {
                font-size: 2rem;
            }
        }

        /* Animations */
        .fade-in-up {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }

        .fade-in-up.visible {
            opacity: 1;
            transform: translateY(0);
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-cloud"></i> <?php echo SITE_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#packages">پکیج‌ها</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">ویژگی‌ها</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#support">پشتیبانی</a>
                    </li>
                </ul>
                
                <div class="navbar-nav">
                    <a class="nav-link" href="login.php">ورود</a>
                    <a class="nav-link btn-login" href="register.php">ثبت نام</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="hero-content" data-aos="fade-up">
                        <h1 class="hero-title">
                            هاستینگ حرفه‌ای
                            <span style="background: linear-gradient(45deg, #f093fb, #f5576c); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">ایران</span>
                        </h1>
                        <p class="hero-subtitle">
                            با بیش از 10 سال تجربه، بهترین سرویس هاستینگ را با آپتایم 99.9% و پشتیبانی 24/7 ارائه می‌دهیم
                        </p>
                        <div class="d-flex gap-3 flex-wrap">
                            <a href="#packages" class="btn btn-hero">
                                <i class="fas fa-rocket me-2"></i>
                                شروع کنید
                            </a>
                            <a href="#features" class="btn btn-outline-light">
                                <i class="fas fa-play me-2"></i>
                                ویژگی‌ها
                            </a>
                        </div>
                        
                        <div class="hero-stats">
                            <div class="hero-stat">
                                <span class="hero-stat-number">10K+</span>
                                <span class="hero-stat-label">مشتری راضی</span>
                            </div>
                            <div class="hero-stat">
                                <span class="hero-stat-number">99.9%</span>
                                <span class="hero-stat-label">آپتایم</span>
                            </div>
                            <div class="hero-stat">
                                <span class="hero-stat-number">24/7</span>
                                <span class="hero-stat-label">پشتیبانی</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-aos="fade-left" data-aos-delay="200">
                    <div class="text-center">
                        <img src="/placeholder.svg?height=500&width=600" alt="Server Illustration" class="img-fluid" style="max-width: 500px;">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-6">
                    <div class="stat-item" data-aos="fade-up" data-aos-delay="100">
                        <span class="stat-number" data-count="15000">0</span>
                        <span class="stat-label">وب سایت میزبانی شده</span>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item" data-aos="fade-up" data-aos-delay="200">
                        <span class="stat-number" data-count="99.9">0</span>
                        <span class="stat-label">درصد آپتایم</span>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item" data-aos="fade-up" data-aos-delay="300">
                        <span class="stat-number" data-count="24">0</span>
                        <span class="stat-label">ساعت پشتیبانی</span>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-item" data-aos="fade-up" data-aos-delay="400">
                        <span class="stat-number" data-count="10">0</span>
                        <span class="stat-label">سال تجربه</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Packages Section -->
    <section id="packages" class="packages-section">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="section-title">پکیج‌های هاستینگ</h2>
                <p class="section-subtitle">بهترین پکیج را برای نیاز خود انتخاب کنید</p>
            </div>
            
            <div class="row g-4">
                <?php foreach ($packages as $index => $package): ?>
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo ($index + 1) * 100; ?>">
                    <div class="package-card <?php echo $index === 1 ? 'featured' : ''; ?>">
                        <?php if ($index === 1): ?>
                            <div class="package-badge">محبوب‌ترین</div>
                        <?php endif; ?>
                        
                        <div class="package-name"><?php echo htmlspecialchars($package['name']); ?></div>
                        <div class="package-description"><?php echo htmlspecialchars($package['description']); ?></div>
                        
                        <div class="package-price">
                            <div class="price-amount">
                                <span class="price-currency">تومان</span>
                                <?php echo number_format($package['price']); ?>
                            </div>
                            <span class="price-period">ماهانه</span>
                        </div>
                        
                        <ul class="package-features">
                            <li>
                                <i class="fas fa-check"></i>
                                <?php echo $package['disk_space']; ?> گیگابایت فضای ذخیره‌سازی SSD
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                <?php echo $package['bandwidth']; ?> گیگابایت ترافیک ماهانه
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                <?php echo $package['email_accounts']; ?> اکانت ایمیل حرفه‌ای
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                <?php echo $package['db_count']; ?> دیتابیس MySQL
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                <?php echo $package['domains']; ?> دامنه اصلی
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                <?php echo $package['subdomains']; ?> ساب دامنه
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                گواهی SSL رایگان
                            </li>
                            <li>
                                <i class="fas fa-check"></i>
                                پشتیبان‌گیری روزانه
                            </li>
                        </ul>
                        
                        <a href="order.php?package=<?php echo $package['id']; ?>" class="btn btn-package">
                            <i class="fas fa-shopping-cart me-2"></i>
                            سفارش این پکیج
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features-section">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="section-title">چرا DimaServer؟</h2>
                <p class="section-subtitle">ویژگی‌هایی که ما را از سایرین متمایز می‌کند</p>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h4 class="feature-title">امنیت بالا</h4>
                        <p class="feature-description">
                            سرورهای ما با آخرین تکنولوژی‌های امنیتی و فایروال پیشرفته محافظت می‌شوند
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-tachometer-alt"></i>
                        </div>
                        <h4 class="feature-title">سرعت بالا</h4>
                        <p class="feature-description">
                            استفاده از SSD و CDN برای بهترین عملکرد و سرعت بارگذاری وب سایت شما
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h4 class="feature-title">پشتیبانی 24/7</h4>
                        <p class="feature-description">
                            تیم پشتیبانی متخصص ما همیشه آماده پاسخگویی و حل مشکلات شما است
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-sync-alt"></i>
                        </div>
                        <h4 class="feature-title">پشتیبان‌گیری خودکار</h4>
                        <p class="feature-description">
                            پشتیبان‌گیری روزانه و خودکار از تمام فایل‌ها و دیتابیس‌های شما
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-globe"></i>
                        </div>
                        <h4 class="feature-title">CDN رایگان</h4>
                        <p class="feature-description">
                            شبکه توزیع محتوا برای بهبود سرعت و عملکرد وب سایت در سراسر جهان
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-tools"></i>
                        </div>
                        <h4 class="feature-title">کنترل پنل آسان</h4>
                        <p class="feature-description">
                            رابط کاربری ساده و قدرتمند برای مدیریت آسان هاستینگ و دامنه شما
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h5><?php echo SITE_NAME; ?></h5>
                    <p>ارائه‌دهنده خدمات هاستینگ حرفه‌ای با بیش از 10 سال تجربه در ایران</p>
                    <div class="social-links mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-telegram"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h5>خدمات</h5>
                    <ul>
                        <li><a href="#">هاستینگ لینوکس</a></li>
                        <li><a href="#">هاستینگ ویندوز</a></li>
                        <li><a href="#">سرور مجازی</a></li>
                        <li><a href="#">سرور اختصاصی</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h5>پشتیبانی</h5>
                    <ul>
                        <li><a href="#">مرکز راهنمایی</a></li>
                        <li><a href="#">تماس با ما</a></li>
                        <li><a href="#">گزارش مشکل</a></li>
                        <li><a href="#">وضعیت سرورها</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h5>تماس با ما</h5>
                    <ul>
                        <li><i class="fas fa-phone me-2"></i> 021-12345678</li>
                        <li><i class="fas fa-envelope me-2"></i> info@dimaserver.ir</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i> تهران، ایران</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 <?php echo SITE_NAME; ?>. تمامی حقوق محفوظ است.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar-custom');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Counter animation
        function animateCounters() {
            const counters = document.querySelectorAll('[data-count]');
            
            counters.forEach(counter => {
                const target = parseFloat(counter.getAttribute('data-count'));
                const increment = target / 100;
                let current = 0;
                
                const updateCounter = () => {
                    if (current < target) {
                        current += increment;
                        if (target % 1 !== 0) {
                            counter.textContent = current.toFixed(1);
                        } else {
                            counter.textContent = Math.ceil(current).toLocaleString();
                        }
                        requestAnimationFrame(updateCounter);
                    } else {
                        if (target % 1 !== 0) {
                            counter.textContent = target.toFixed(1);
                        } else {
                            counter.textContent = target.toLocaleString();
                        }
                    }
                };
                
                updateCounter();
            });
        }

        // Trigger counter animation when stats section is visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        });

        const statsSection = document.querySelector('.stats-section');
        if (statsSection) {
            observer.observe(statsSection);
        }

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Add loading state to buttons
        document.querySelectorAll('.btn-package').forEach(btn => {
            btn.addEventListener('click', function(e) {
                const originalText = this.innerHTML;
                this.innerHTML = '<span class="loading"></span> در حال پردازش...';
                this.disabled = true;
                
                // Re-enable after 2 seconds (for demo)
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 2000);
            });
        });
    </script>
</body>
</html>
