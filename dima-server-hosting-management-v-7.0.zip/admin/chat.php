<?php
require_once '../config/config.php';
require_once '../includes/auth.php';
require_once '../models/Chat.php';

$auth = new Auth();
if (!$auth->isLoggedIn() || !$auth->isAdmin()) {
    header('Location: ../login.php');
    exit;
}

$chat = new Chat();
$sessions = $chat->getActiveSessions();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت چت - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f8fafc; }
        .chat-admin-container { display: flex; height: calc(100vh - 60px); }
        .sessions-sidebar { width: 300px; background: white; border-left: 1px solid #e5e7eb; }
        .chat-main { flex: 1; display: flex; flex-direction: column; }
        .session-item { padding: 1rem; border-bottom: 1px solid #f3f4f6; cursor: pointer; transition: background 0.2s; }
        .session-item:hover { background: #f9fafb; }
        .session-item.active { background: #eff6ff; border-left: 3px solid #2563eb; }
        .session-name { font-weight: 600; margin-bottom: 0.25rem; }
        .session-email { font-size: 0.875rem; color: #6b7280; margin-bottom: 0.25rem; }
        .session-time { font-size: 0.75rem; color: #9ca3af; }
        .chat-header { background: white; padding: 1rem; border-bottom: 1px solid #e5e7eb; }
        .chat-messages { flex: 1; padding: 1rem; overflow-y: auto; background: #f8fafc; }
        .chat-input { background: white; padding: 1rem; border-top: 1px solid #e5e7eb; }
        .message { margin-bottom: 1rem; display: flex; }
        .message.admin { justify-content: flex-end; }
        .message-content { max-width: 70%; padding: 0.75rem 1rem; border-radius: 1rem; }
        .message.user .message-content { background: #e5e7eb; color: #1f2937; }
        .message.admin .message-content { background: #2563eb; color: white; }
        .empty-state { text-align: center; padding: 3rem; color: #6b7280; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-tachometer-alt me-2"></i>
                پنل مدیریت
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../logout.php">خروج</a>
            </div>
        </div>
    </nav>

    <div class="chat-admin-container">
        <!-- Sessions Sidebar -->
        <div class="sessions-sidebar">
            <div class="p-3 border-bottom">
                <h5 class="mb-0">
                    <i class="fas fa-comments me-2"></i>
                    چت‌های فعال
                </h5>
            </div>
            <div id="sessionsList">
                <?php if (empty($sessions)): ?>
                    <div class="p-3 text-center text-muted">
                        <i class="fas fa-inbox fa-2x mb-2"></i>
                        <p>چت فعالی وجود ندارد</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($sessions as $session): ?>
                        <div class="session-item" data-session-id="<?php echo $session['session_id']; ?>">
                            <div class="session-name"><?php echo htmlspecialchars($session['name']); ?></div>
                            <div class="session-email"><?php echo htmlspecialchars($session['email']); ?></div>
                            <div class="session-time">
                                <?php echo $session['last_message_time'] ? 
                                    date('H:i', strtotime($session['last_message_time'])) : 
                                    date('H:i', strtotime($session['created_at'])); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Chat Main -->
        <div class="chat-main">
            <div id="chatHeader" class="chat-header" style="display: none;">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1" id="currentSessionName">نام کاربر</h6>
                        <small class="text-muted" id="currentSessionEmail">email@example.com</small>
                    </div>
                    <button class="btn btn-outline-danger btn-sm" id="closeSession">
                        <i class="fas fa-times me-1"></i>
                        بستن چت
                    </button>
                </div>
            </div>

            <div id="chatMessages" class="chat-messages" style="display: none;">
                <!-- Messages will be loaded here -->
            </div>

            <div id="chatInput" class="chat-input" style="display: none;">
                <div class="input-group">
                    <input type="text" id="messageInput" class="form-control" placeholder="پیام خود را بنویسید...">
                    <button class="btn btn-primary" id="sendBtn">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>

            <div id="emptyState" class="empty-state">
                <i class="fas fa-comments fa-3x mb-3"></i>
                <h5>یک چت را انتخاب کنید</h5>
                <p>برای شروع گفتگو، یکی از چت‌های فعال را از سمت راست انتخاب کنید</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        class ChatAdmin {
            constructor() {
                this.currentSessionId = null;
                this.lastMessageId = 0;
                this.pollInterval = null;
                this.init();
            }

            init() {
                this.bindEvents();
                this.startSessionPolling();
            }

            bindEvents() {
                // Session selection
                document.addEventListener('click', (e) => {
                    const sessionItem = e.target.closest('.session-item');
                    if (sessionItem) {
                        this.selectSession(sessionItem.dataset.sessionId);
                    }
                });

                // Send message
                document.getElementById('sendBtn').addEventListener('click', () => {
                    this.sendMessage();
                });

                document.getElementById('messageInput').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        this.sendMessage();
                    }
                });

                // Close session
                document.getElementById('closeSession').addEventListener('click', () => {
                    this.closeCurrentSession();
                });
            }

            selectSession(sessionId) {
                // Update UI
                document.querySelectorAll('.session-item').forEach(item => {
                    item.classList.remove('active');
                });
                document.querySelector(`[data-session-id="${sessionId}"]`).classList.add('active');

                this.currentSessionId = sessionId;
                this.lastMessageId = 0;
                
                this.showChatInterface();
                this.loadMessages();
                this.startMessagePolling();
            }

            showChatInterface() {
                document.getElementById('emptyState').style.display = 'none';
                document.getElementById('chatHeader').style.display = 'block';
                document.getElementById('chatMessages').style.display = 'block';
                document.getElementById('chatInput').style.display = 'block';
            }

            async loadMessages() {
                if (!this.currentSessionId) return;

                try {
                    const response = await fetch(`../api/chat.php?action=messages&session_id=${this.currentSessionId}`);
                    const data = await response.json();

                    if (data.success) {
                        const messagesContainer = document.getElementById('chatMessages');
                        messagesContainer.innerHTML = '';

                        data.messages.forEach(msg => {
                            this.addMessage(msg.sender_type, msg.message, new Date(msg.created_at));
                            this.lastMessageId = Math.max(this.lastMessageId, msg.id);
                        });

                        messagesContainer.scrollTop = messagesContainer.scrollHeight;
                    }
                } catch (error) {
                    console.error('Error loading messages:', error);
                }
            }

            async sendMessage() {
                const input = document.getElementById('messageInput');
                const message = input.value.trim();

                if (!message || !this.currentSessionId) return;

                try {
                    const response = await fetch('../api/chat.php?action=send', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            session_id: this.currentSessionId,
                            message: message,
                            sender_type: 'admin'
                        })
                    });

                    const data = await response.json();

                    if (data.success) {
                        this.addMessage('admin', message, new Date());
                        input.value = '';
                    }
                } catch (error) {
                    console.error('Error sending message:', error);
                }
            }

            addMessage(sender, message, time) {
                const messagesContainer = document.getElementById('chatMessages');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${sender}`;

                const timeStr = time.toLocaleTimeString('fa-IR', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                });

                messageDiv.innerHTML = `
                    <div class="message-content">
                        ${this.escapeHtml(message)}
                        <div style="font-size: 0.75rem; opacity: 0.7; margin-top: 0.25rem;">
                            ${timeStr}
                        </div>
                    </div>
                `;

                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }

            startMessagePolling() {
                this.stopMessagePolling();
                this.messageInterval = setInterval(() => {
                    this.loadNewMessages();
                }, 2000);
            }

            stopMessagePolling() {
                if (this.messageInterval) {
                    clearInterval(this.messageInterval);
                }
            }

            async loadNewMessages() {
                if (!this.currentSessionId) return;

                try {
                    const response = await fetch(`../api/chat.php?action=messages&session_id=${this.currentSessionId}&last_id=${this.lastMessageId}`);
                    const data = await response.json();

                    if (data.success && data.messages.length > 0) {
                        data.messages.forEach(msg => {
                            if (msg.id > this.lastMessageId) {
                                this.addMessage(msg.sender_type, msg.message, new Date(msg.created_at));
                                this.lastMessageId = msg.id;
                            }
                        });
                    }
                } catch (error) {
                    console.error('Error loading new messages:', error);
                }
            }

            startSessionPolling() {
                setInterval(() => {
                    this.refreshSessions();
                }, 10000);
            }

            async refreshSessions() {
                try {
                    const response = await fetch('../api/chat.php?action=sessions');
                    const data = await response.json();

                    if (data.success) {
                        // Update sessions list if needed
                        // This is a simplified version - you might want to implement proper diff
                    }
                } catch (error) {
                    console.error('Error refreshing sessions:', error);
                }
            }

            escapeHtml(text) {
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
        }

        // Initialize
        new ChatAdmin();
    </script>
</body>
</html>
