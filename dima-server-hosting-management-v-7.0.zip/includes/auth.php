<?php
require_once __DIR__ . '/../config/database.php';

// بررسی وجود autoload
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
} else {
    // اگر Composer نصب نیست، از کلاس‌های ساده استفاده می‌کنیم
    require_once __DIR__ . '/simple-jwt.php';
}

// استفاده از JWT اگر موجود باشد
if (class_exists('Firebase\JWT\JWT')) {
    use Firebase\JWT\JWT;
    use Firebase\JWT\Key;
    $jwt_available = true;
} else {
    $jwt_available = false;
}

class Auth {
    private $conn;
    private $jwt_available;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
        $this->jwt_available = class_exists('Firebase\JWT\JWT');
    }
    
    public function register($username, $email, $password, $full_name, $phone) {
        // بررسی وجود کاربر
        $query = "SELECT id FROM users WHERE username = ? OR email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$username, $email]);
        
        if ($stmt->rowCount() > 0) {
            return ['success' => false, 'message' => 'نام کاربری یا ایمیل قبلاً ثبت شده است'];
        }
        
        // رمزگذاری پسورد
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // درج کاربر جدید
        $query = "INSERT INTO users (username, email, password, full_name, phone, created_at) 
                  VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        
        if ($stmt->execute([$username, $email, $hashed_password, $full_name, $phone])) {
            return ['success' => true, 'message' => 'ثبت نام با موفقیت انجام شد'];
        }
        
        return ['success' => false, 'message' => 'خطا در ثبت نام'];
    }
    
    public function login($username, $password) {
        $query = "SELECT id, username, email, password, role, status FROM users 
                  WHERE (username = ? OR email = ?) AND status = 'active'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$username, $username]);
        
        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($password, $user['password'])) {
                // ایجاد JWT Token اگر موجود باشد
                $token = null;
                if ($this->jwt_available) {
                    $payload = [
                        'user_id' => $user['id'],
                        'username' => $user['username'],
                        'role' => $user['role'],
                        'exp' => time() + (24 * 60 * 60) // 24 ساعت
                    ];
                    
                    $token = JWT::encode($payload, JWT_SECRET, 'HS256');
                }
                
                // ذخیره در session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                if ($token) {
                    $_SESSION['token'] = $token;
                }
                
                return ['success' => true, 'user' => $user, 'token' => $token];
            }
        }
        
        return ['success' => false, 'message' => 'نام کاربری یا رمز عبور اشتباه است'];
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    public function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
    
    public function logout() {
        session_destroy();
        return true;
    }
    
    public function getCurrentUser() {
        if ($this->isLoggedIn()) {
            $query = "SELECT * FROM users WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$_SESSION['user_id']]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return null;
    }
}
?>
