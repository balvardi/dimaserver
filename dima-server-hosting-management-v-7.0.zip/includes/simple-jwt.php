<?php
/**
 * کلاس ساده JWT برای زمانی که Firebase JWT نصب نیست
 * این کلاس فقط برای compatibility است و برای production توصیه نمی‌شود
 */

if (!class_exists('Firebase\JWT\JWT')) {
    class SimpleJWT {
        public static function encode($payload, $key, $alg = 'HS256') {
            $header = json_encode(['typ' => 'JWT', 'alg' => $alg]);
            $payload = json_encode($payload);
            
            $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
            $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
            
            $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $key, true);
            $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
            
            return $base64Header . "." . $base64Payload . "." . $base64Signature;
        }
        
        public static function decode($jwt, $key, $algorithms = ['HS256']) {
            $parts = explode('.', $jwt);
            if (count($parts) != 3) {
                throw new Exception('Wrong number of segments');
            }
            
            list($base64Header, $base64Payload, $base64Signature) = $parts;
            
            $header = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64Header)), true);
            $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64Payload)), true);
            
            if (!in_array($header['alg'], $algorithms)) {
                throw new Exception('Algorithm not allowed');
            }
            
            $signature = base64_decode(str_replace(['-', '_'], ['+', '/'], $base64Signature));
            $expectedSignature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $key, true);
            
            if (!hash_equals($signature, $expectedSignature)) {
                throw new Exception('Signature verification failed');
            }
            
            if (isset($payload['exp']) && $payload['exp'] < time()) {
                throw new Exception('Token has expired');
            }
            
            return $payload;
        }
    }
    
    // ایجاد alias برای سازگاری
    class_alias('SimpleJWT', 'Firebase\JWT\JWT');
}
?>
