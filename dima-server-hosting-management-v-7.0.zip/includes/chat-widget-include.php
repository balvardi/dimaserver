<?php
// این فایل را در انتهای layout اصلی include کنید
?>
<!-- Chat Widget Include -->
<?php include 'components/chat-widget.html'; ?>

<script>
// تنظیمات اضافی برای چت
document.addEventListener('DOMContentLoaded', function() {
    // اگر کاربر لاگین است، اطلاعات را از سشن بگیرید
    <?php if (isset($_SESSION['user_id'])): ?>
        const user = <?php echo json_encode([
            'name' => $_SESSION['username'] ?? '',
            'email' => $auth->getCurrentUser()['email'] ?? ''
        ]); ?>;
        
        // Pre-fill user info if logged in
        if (user.name) document.getElementById('userName').value = user.name;
        if (user.email) document.getElementById('userEmail').value = user.email;
    <?php endif; ?>
});
</script>
