<?php
class ZarinPal {
    private $merchant_id;
    private $sandbox;
    private $zarinpal_url;
    
    public function __construct() {
        $this->merchant_id = ZARINPAL_MERCHANT_ID;
        $this->sandbox = ZARINPAL_SANDBOX;
        $this->zarinpal_url = $this->sandbox ? 
            'https://sandbox.zarinpal.com/pg/rest/WebGate/' : 
            'https://api.zarinpal.com/pg/rest/WebGate/';
    }
    
    public function request($amount, $description, $callback_url, $email = '', $mobile = '') {
        $data = [
            'merchant_id' => $this->merchant_id,
            'amount' => $amount,
            'description' => $description,
            'callback_url' => $callback_url,
            'metadata' => [
                'email' => $email,
                'mobile' => $mobile
            ]
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->zarinpal_url . 'PaymentRequest.json');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen(json_encode($data))
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($response, true);
        
        if ($result['data']['code'] == 100) {
            $authority = $result['data']['authority'];
            $payment_url = $this->sandbox ? 
                'https://sandbox.zarinpal.com/pg/StartPay/' . $authority :
                'https://www.zarinpal.com/pg/StartPay/' . $authority;
                
            return ['success' => true, 'authority' => $authority, 'url' => $payment_url];
        }
        
        return ['success' => false, 'error' => $result['errors']];
    }
    
    public function verify($authority, $amount) {
        $data = [
            'merchant_id' => $this->merchant_id,
            'authority' => $authority,
            'amount' => $amount
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->zarinpal_url . 'PaymentVerification.json');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen(json_encode($data))
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($response, true);
        
        if ($result['data']['code'] == 100 || $result['data']['code'] == 101) {
            return [
                'success' => true, 
                'ref_id' => $result['data']['ref_id'],
                'code' => $result['data']['code']
            ];
        }
        
        return ['success' => false, 'error' => $result['errors']];
    }
}
?>
