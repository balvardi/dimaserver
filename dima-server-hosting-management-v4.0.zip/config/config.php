<?php
// تنظیمات کلی سایت
define('SITE_NAME', 'DimaServer.ir');
define('SITE_URL', 'https://dimaserver.ir');
define('ADMIN_EMAIL', 'admin@dimaserver.ir');

// تنظیمات DirectAdmin
define('DA_HOST', 'your-server.com');
define('DA_PORT', '2222');
define('DA_USERNAME', 'admin');
define('DA_PASSWORD', 'your_admin_password');

// تنظیمات زرین‌پال
define('ZARINPAL_MERCHANT_ID', 'your-zarinpal-merchant-id');
define('ZARINPAL_SANDBOX', false); // true برای تست

// تنظیمات امنیتی
define('JWT_SECRET', 'your-very-secure-jwt-secret-key-here');
define('ENCRYPTION_KEY', 'your-32-character-encryption-key');

// تنظیمات ایمیل
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-email-password');

session_start();
?>
