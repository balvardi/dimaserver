<?php
require_once 'config/config.php';
require_once 'models/Package.php';

$packageModel = new Package();
$packages = $packageModel->getAll();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - هاستینگ حرفه‌ای</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Tahoma', sans-serif; }
        .hero-section { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 100px 0; }
        .package-card { transition: transform 0.3s; border: none; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .package-card:hover { transform: translateY(-5px); }
        .price { font-size: 2rem; font-weight: bold; color: #667eea; }
        .feature-list { list-style: none; padding: 0; }
        .feature-list li { padding: 5px 0; }
        .feature-list li i { color: #28a745; margin-left: 10px; }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-server"></i> <?php echo SITE_NAME; ?>
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="login.php">ورود</a>
                <a class="nav-link" href="register.php">ثبت نام</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 mb-4">هاستینگ حرفه‌ای با کیفیت بالا</h1>
            <p class="lead mb-4">بهترین سرویس هاستینگ با پشتیبانی 24 ساعته و آپتایم 99.9%</p>
            <a href="#packages" class="btn btn-light btn-lg">مشاهده پکیج‌ها</a>
        </div>
    </section>

    <!-- Packages Section -->
    <section id="packages" class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2>پکیج‌های هاستینگ</h2>
                <p class="text-muted">بهترین پکیج را برای نیاز خود انتخاب کنید</p>
            </div>
            
            <div class="row">
                <?php foreach ($packages as $package): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card package-card h-100">
                        <div class="card-header text-center bg-primary text-white">
                            <h4><?php echo htmlspecialchars($package['name']); ?></h4>
                        </div>
                        <div class="card-body text-center">
                            <div class="price mb-3">
                                <?php echo number_format($package['price']); ?> تومان
                                <small class="text-muted d-block">ماهانه</small>
                            </div>
                            
                            <ul class="feature-list">
                                <li><i class="fas fa-check"></i> <?php echo $package['disk_space']; ?> گیگابایت فضا</li>
                                <li><i class="fas fa-check"></i> <?php echo $package['bandwidth']; ?> گیگابایت ترافیک</li>
                                <li><i class="fas fa-check"></i> <?php echo $package['email_accounts']; ?> اکانت ایمیل</li>
                                <li><i class="fas fa-check"></i> <?php echo $package['db_count']; ?> دیتابیس MySQL</li>
                                <li><i class="fas fa-check"></i> <?php echo $package['domains']; ?> دامنه</li>
                                <li><i class="fas fa-check"></i> <?php echo $package['subdomains']; ?> ساب دامنه</li>
                            </ul>
                            
                            <p class="text-muted mt-3"><?php echo htmlspecialchars($package['description']); ?></p>
                        </div>
                        <div class="card-footer">
                            <a href="order.php?package=<?php echo $package['id']; ?>" class="btn btn-primary w-100">
                                سفارش این پکیج
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2>چرا DimaServer؟</h2>
            </div>
            <div class="row">
                <div class="col-md-4 text-center mb-4">
                    <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                    <h4>امنیت بالا</h4>
                    <p>سرورهای ما با بالاترین استانداردهای امنیتی محافظت می‌شوند</p>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <i class="fas fa-clock fa-3x text-primary mb-3"></i>
                    <h4>آپتایم 99.9%</h4>
                    <p>تضمین دسترسی مداوم به وب سایت شما</p>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <i class="fas fa-headset fa-3x text-primary mb-3"></i>
                    <h4>پشتیبانی 24/7</h4>
                    <p>تیم پشتیبانی ما همیشه آماده کمک به شما است</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p>&copy; 2024 <?php echo SITE_NAME; ?>. تمامی حقوق محفوظ است.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
