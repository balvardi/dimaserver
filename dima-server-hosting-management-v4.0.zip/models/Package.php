<?php
require_once 'config/database.php';

class Package {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function create($name, $description, $price, $disk_space, $bandwidth, $email_accounts, $db_count, $domains, $subdomains, $features) {
        $query = "INSERT INTO packages (name, description, price, disk_space, bandwidth, email_accounts, db_count, domains, subdomains, features, status, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            $name, $description, $price, $disk_space, $bandwidth, 
            $email_accounts, $db_count, $domains, $subdomains, 
            json_encode($features)
        ]);
    }
    
    public function getAll($status = 'active') {
        $query = "SELECT * FROM packages WHERE status = ? ORDER BY price ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$status]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getById($id) {
        $query = "SELECT * FROM packages WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function update($id, $data) {
        $fields = [];
        $values = [];
        
        foreach ($data as $key => $value) {
            if ($key === 'features') {
                $value = json_encode($value);
            }
            $fields[] = "$key = ?";
            $values[] = $value;
        }
        
        $values[] = $id;
        $query = "UPDATE packages SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute($values);
    }
    
    public function delete($id) {
        $query = "UPDATE packages SET status = 'deleted' WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }
}
?>
