-- ایجاد دیتابیس
CREATE DATABASE IF NOT EXISTS dimaserver_hosting CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dimaserver_hosting;

-- جدول کاربران
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول پکیج‌های هاستینگ
CREATE TABLE packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    disk_space INT NOT NULL COMMENT 'به گیگابایت',
    bandwidth INT NOT NULL COMMENT 'به گیگابایت', 
    email_accounts INT NOT NULL,
    db_count INT NOT NULL COMMENT 'تعداد دیتابیس',
    domains INT NOT NULL,
    subdomains INT NOT NULL,
    features JSON,
    status ENUM('active', 'inactive', 'deleted') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول سفارشات
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(20) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    domain VARCHAR(100) NOT NULL,
    period INT DEFAULT 1 COMMENT 'تعداد ماه',
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'paid', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    transaction_id VARCHAR(100),
    authority VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (package_id) REFERENCES packages(id)
);

-- جدول اکانت‌های هاستینگ
CREATE TABLE hosting_accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_id INT NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    domain VARCHAR(100) NOT NULL,
    package_id INT NOT NULL,
    status ENUM('active', 'suspended', 'terminated') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (package_id) REFERENCES packages(id)
);

-- جدول تراکنش‌ها
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    gateway VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100),
    authority VARCHAR(100),
    ref_id VARCHAR(100),
    status ENUM('pending', 'success', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- جدول تیکت‌های پشتیبانی
CREATE TABLE support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    status ENUM('open', 'in_progress', 'closed') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ایجاد کاربر ادمین پیش‌فرض (رمز عبور: admin123)
INSERT INTO users (username, email, password, full_name, role) 
VALUES ('admin', 'admin@dimaserver.ir', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدیر سیستم', 'admin');

-- درج پکیج‌های نمونه
INSERT INTO packages (name, description, price, disk_space, bandwidth, email_accounts, db_count, domains, subdomains, features) VALUES
('پایه', 'پکیج مناسب برای وب سایت‌های شخصی', 50000, 5, 50, 10, 2, 1, 5, '["SSL رایگان", "پشتیبانی ایمیل", "کنترل پنل"]'),
('حرفه‌ای', 'پکیج مناسب برای کسب و کارهای کوچک', 120000, 15, 150, 25, 5, 3, 15, '["SSL رایگان", "پشتیبانی ایمیل", "کنترل پنل", "پشتیبان‌گیری روزانه"]'),
('پیشرفته', 'پکیج مناسب برای وب سایت‌های پربازدید', 250000, 50, 500, 50, 10, 10, 50, '["SSL رایگان", "پشتیبانی ایمیل", "کنترل پنل", "پشتیبان‌گیری روزانه", "CDN رایگان"]');
