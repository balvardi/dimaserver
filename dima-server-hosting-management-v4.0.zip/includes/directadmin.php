<?php
class DirectAdmin {
    private $host;
    private $port;
    private $username;
    private $password;
    
    public function __construct() {
        $this->host = DA_HOST;
        $this->port = DA_PORT;
        $this->username = DA_USERNAME;
        $this->password = DA_PASSWORD;
    }
    
    private function makeRequest($command, $data = []) {
        $url = "http://{$this->host}:{$this->port}/{$command}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $this->username . ':' . $this->password);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode == 200) {
            return ['success' => true, 'data' => $response];
        }
        
        return ['success' => false, 'error' => 'خطا در اتصال به DirectAdmin'];
    }
    
    public function createAccount($username, $email, $password, $domain, $package) {
        $data = [
            'action' => 'create',
            'add' => 'Submit',
            'username' => $username,
            'email' => $email,
            'passwd' => $password,
            'passwd2' => $password,
            'domain' => $domain,
            'package' => $package,
            'ip' => 'shared',
            'notify' => 'yes'
        ];
        
        return $this->makeRequest('CMD_ACCOUNT_USER', $data);
    }
    
    public function suspendAccount($username) {
        $data = [
            'suspend' => 'Suspend',
            'select0' => $username
        ];
        
        return $this->makeRequest('CMD_SELECT_USERS', $data);
    }
    
    public function unsuspendAccount($username) {
        $data = [
            'unsuspend' => 'Unsuspend',
            'select0' => $username
        ];
        
        return $this->makeRequest('CMD_SELECT_USERS', $data);
    }
    
    public function deleteAccount($username) {
        $data = [
            'confirmed' => 'Confirm',
            'delete' => 'yes',
            'select0' => $username
        ];
        
        return $this->makeRequest('CMD_SELECT_USERS', $data);
    }
    
    public function getAccountInfo($username) {
        $data = ['user' => $username];
        return $this->makeRequest('CMD_SHOW_USER_CONFIG', $data);
    }
    
    public function createPackage($name, $bandwidth, $quota, $domains, $subdomains, $email_accounts) {
        $data = [
            'action' => 'create',
            'add' => 'Save',
            'packagename' => $name,
            'bandwidth' => $bandwidth,
            'quota' => $quota,
            'vdomains' => $domains,
            'nsubdomains' => $subdomains,
            'nemails' => $email_accounts,
            'mysql' => 'unlimited',
            'ftp' => 'unlimited',
            'cgi' => 'ON',
            'php' => 'ON',
            'ssl' => 'ON'
        ];
        
        return $this->makeRequest('CMD_PACKAGES_USER', $data);
    }
}
?>
