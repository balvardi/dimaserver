<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
require_once 'models/Order.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = $auth->getCurrentUser();
$orderModel = new Order();
$orders = $orderModel->getByUser($user['id']);

// دریافت اطلاعات اکانت‌های هاستینگ
$database = new Database();
$conn = $database->getConnection();

$query = "SELECT ha.*, p.name as package_name 
          FROM hosting_accounts ha 
          JOIN packages p ON ha.package_id = p.id 
          WHERE ha.user_id = ? 
          ORDER BY ha.created_at DESC";
$stmt = $conn->prepare($query);
$stmt->execute([$user['id']]);
$hosting_accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل کاربری - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Tahoma', sans-serif; background: #f8f9fa; }
        .dashboard-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px 0; }
        .stats-card { border-left: 4px solid #007bff; }
        .hosting-card { transition: transform 0.2s; }
        .hosting-card:hover { transform: translateY(-2px); }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2>خوش آمدید، <?php echo htmlspecialchars($user['full_name']); ?></h2>
                    <p class="mb-0">پنل مدیریت هاستینگ شما</p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="index.php" class="btn btn-light me-2">صفحه اصلی</a>
                    <a href="logout.php" class="btn btn-outline-light">خروج</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">کل سفارشات</h6>
                                <h4><?php echo count($orders); ?></h4>
                            </div>
                            <i class="fas fa-shopping-cart fa-2x text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">هاستینگ فعال</h6>
                                <h4><?php echo count(array_filter($hosting_accounts, fn($h) => $h['status'] === 'active')); ?></h4>
                            </div>
                            <i class="fas fa-server fa-2x text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">سفارشات موفق</h6>
                                <h4><?php echo count(array_filter($orders, fn($o) => $o['status'] === 'completed')); ?></h4>
                            </div>
                            <i class="fas fa-check fa-2x text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="text-muted">در انتظار پرداخت</h6>
                                <h4><?php echo count(array_filter($orders, fn($o) => $o['status'] === 'pending')); ?></h4>
                            </div>
                            <i class="fas fa-clock fa-2x text-warning"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Hosting Accounts -->
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="fas fa-server"></i> اکانت‌های هاستینگ</h5>
                        <a href="index.php#packages" class="btn btn-primary btn-sm">خرید هاستینگ جدید</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($hosting_accounts)): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-server fa-3x text-muted mb-3"></i>
                                <h5>هیچ اکانت هاستینگی ندارید</h5>
                                <p class="text-muted">برای شروع، یک پکیج هاستینگ خریداری کنید</p>
                                <a href="index.php#packages" class="btn btn-primary">مشاهده پکیج‌ها</a>
                            </div>
                        <?php else: ?>
                            <?php foreach ($hosting_accounts as $account): ?>
                            <div class="card hosting-card mb-3">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-md-8">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($account['domain']); ?></h6>
                                            <p class="text-muted mb-1">
                                                پکیج: <?php echo htmlspecialchars($account['package_name']); ?> | 
                                                نام کاربری: <?php echo htmlspecialchars($account['username']); ?>
                                            </p>
                                            <small class="text-muted">
                                                انقضا: <?php echo date('Y/m/d', strtotime($account['expires_at'])); ?>
                                            </small>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <?php
                                            $statusClass = [
                                                'active' => 'success',
                                                'suspended' => 'warning',
                                                'terminated' => 'danger'
                                            ];
                                            $statusText = [
                                                'active' => 'فعال',
                                                'suspended' => 'معلق',
                                                'terminated' => 'خاتمه یافته'
                                            ];
                                            ?>
                                            <span class="badge bg-<?php echo $statusClass[$account['status']]; ?> mb-2">
                                                <?php echo $statusText[$account['status']]; ?>
                                            </span>
                                            <br>
                                            <a href="http://<?php echo DA_HOST; ?>:2222" target="_blank" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-external-link-alt"></i> کنترل پنل
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-history"></i> آخرین سفارشات</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($orders)): ?>
                            <p class="text-muted text-center">هیچ سفارشی ندارید</p>
                        <?php else: ?>
                            <?php foreach (array_slice($orders, 0, 5) as $order): ?>
                            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                                <div>
                                    <h6 class="mb-1"><?php echo $order['order_number']; ?></h6>
                                    <small class="text-muted"><?php echo $order['package_name']; ?></small>
                                </div>
                                <div class="text-end">
                                    <?php
                                    $statusClass = [
                                        'pending' => 'warning',
                                        'paid' => 'info',
                                        'completed' => 'success',
                                        'failed' => 'danger',
                                        'cancelled' => 'secondary'
                                    ];
                                    $statusText = [
                                        'pending' => 'در انتظار',
                                        'paid' => 'پرداخت شده',
                                        'completed' => 'تکمیل',
                                        'failed' => 'ناموفق',
                                        'cancelled' => 'لغو شده'
                                    ];
                                    ?>
                                    <span class="badge bg-<?php echo $statusClass[$order['status']]; ?>">
                                        <?php echo $statusText[$order['status']]; ?>
                                    </span>
                                    <br>
                                    <small class="text-muted"><?php echo number_format($order['amount']); ?> تومان</small>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5><i class="fas fa-bolt"></i> عملیات سریع</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="index.php#packages" class="btn btn-primary">
                                <i class="fas fa-plus"></i> خرید هاستینگ جدید
                            </a>
                            <a href="support.php" class="btn btn-outline-primary">
                                <i class="fas fa-headset"></i> پشتیبانی
                            </a>
                            <a href="profile.php" class="btn btn-outline-secondary">
                                <i class="fas fa-user-edit"></i> ویرایش پروفایل
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
