<?php
require_once 'config/config.php';
require_once 'includes/auth.php';
require_once 'models/Package.php';
require_once 'models/Order.php';
require_once 'includes/zarinpal.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$packageModel = new Package();
$orderModel = new Order();

if (!isset($_GET['package'])) {
    header('Location: index.php');
    exit;
}

$package = $packageModel->getById($_GET['package']);
if (!$package) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $domain = trim($_POST['domain']);
    $period = (int)$_POST['period'];
    
    if (empty($domain)) {
        $error = 'لطفا نام دامنه را وارد کنید';
    } elseif (!filter_var('http://' . $domain, FILTER_VALIDATE_URL)) {
        $error = 'نام دامنه معتبر نیست';
    } else {
        $amount = $package['price'] * $period;
        $user = $auth->getCurrentUser();
        
        // ایجاد سفارش
        $order_id = $orderModel->create($user['id'], $package['id'], $domain, $period, $amount);
        
        if ($order_id) {
            // ارسال به درگاه پرداخت
            $zarinpal = new ZarinPal();
            $callback_url = SITE_URL . '/payment_callback.php?order_id=' . $order_id;
            $description = "خرید هاستینگ {$package['name']} برای دامنه {$domain}";
            
            $payment = $zarinpal->request($amount, $description, $callback_url, $user['email']);
            
            if ($payment['success']) {
                // ذخیره authority در سفارش
                $orderModel->updateStatus($order_id, 'pending', $payment['authority']);
                header('Location: ' . $payment['url']);
                exit;
            } else {
                $error = 'خطا در اتصال به درگاه پرداخت';
            }
        } else {
            $error = 'خطا در ایجاد سفارش';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سفارش <?php echo htmlspecialchars($package['name']); ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Tahoma', sans-serif; background: #f8f9fa; }
        .order-card { max-width: 600px; margin: 50px auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card order-card">
            <div class="card-header bg-primary text-white text-center">
                <h4>سفارش پکیج <?php echo htmlspecialchars($package['name']); ?></h4>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <!-- Package Details -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5>مشخصات پکیج:</h5>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-hdd text-primary"></i> فضا: <?php echo $package['disk_space']; ?> گیگابایت</li>
                            <li><i class="fas fa-exchange-alt text-primary"></i> ترافیک: <?php echo $package['bandwidth']; ?> گیگابایت</li>
                            <li><i class="fas fa-envelope text-primary"></i> ایمیل: <?php echo $package['email_accounts']; ?> اکانت</li>
                            <li><i class="fas fa-database text-primary"></i> دیتابیس: <?php echo $package['databases']; ?> عدد</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h5>قیمت:</h5>
                        <div class="h4 text-primary"><?php echo number_format($package['price']); ?> تومان/ماه</div>
                        <p class="text-muted"><?php echo htmlspecialchars($package['description']); ?></p>
                    </div>
                </div>
                
                <!-- Order Form -->
                <form method="POST">
                    <div class="mb-3">
                        <label for="domain" class="form-label">نام دامنه *</label>
                        <input type="text" class="form-control" id="domain" name="domain" 
                               placeholder="example.com" required>
                        <div class="form-text">نام دامنه را بدون www وارد کنید</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="period" class="form-label">مدت زمان</label>
                        <select class="form-select" id="period" name="period">
                            <option value="1">1 ماه - <?php echo number_format($package['price']); ?> تومان</option>
                            <option value="3">3 ماه - <?php echo number_format($package['price'] * 3 * 0.95); ?> تومان (5% تخفیف)</option>
                            <option value="6">6 ماه - <?php echo number_format($package['price'] * 6 * 0.9); ?> تومان (10% تخفیف)</option>
                            <option value="12">12 ماه - <?php echo number_format($package['price'] * 12 * 0.8); ?> تومان (20% تخفیف)</option>
                        </select>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-credit-card"></i> پرداخت و سفارش
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">بازگشت</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // محاسبه قیمت بر اساس مدت زمان
        document.getElementById('period').addEventListener('change', function() {
            const basePrice = <?php echo $package['price']; ?>;
            const period = parseInt(this.value);
            let totalPrice = basePrice * period;
            
            // اعمال تخفیف
            if (period >= 12) totalPrice *= 0.8;
            else if (period >= 6) totalPrice *= 0.9;
            else if (period >= 3) totalPrice *= 0.95;
            
            // به‌روزرسانی متن گزینه‌ها
            const options = this.options;
            for (let i = 0; i < options.length; i++) {
                const optionPeriod = parseInt(options[i].value);
                let optionPrice = basePrice * optionPeriod;
                
                if (optionPeriod >= 12) optionPrice *= 0.8;
                else if (optionPeriod >= 6) optionPrice *= 0.9;
                else if (optionPeriod >= 3) optionPrice *= 0.95;
                
                let discountText = '';
                if (optionPeriod >= 12) discountText = ' (20% تخفیف)';
                else if (optionPeriod >= 6) discountText = ' (10% تخفیف)';
                else if (optionPeriod >= 3) discountText = ' (5% تخفیف)';
                
                options[i].text = `${optionPeriod} ماه - ${optionPrice.toLocaleString()} تومان${discountText}`;
            }
        });
    </script>
</body>
</html>
